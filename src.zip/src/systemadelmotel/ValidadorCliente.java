package systemadelmotel;

import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.*;

public class ValidadorCliente {

    private static final String URL = "jdbc:mysql://localhost:3306/mydb";
    private static final String USER = "root";
    private static final String PASS = "Romero10251530$";

    public static boolean identificacionExiste(String cedula) {
        boolean existe = false;

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement("SELECT 1 FROM cliente1 WHERE Identificacion = ?")) {
            
            pst.setString(1, cedula);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                existe = true;
            }

        } catch (SQLException e) {
            System.err.println("Error en validación de cédula: " + e.getMessage());
        }

        return existe;
    }
}