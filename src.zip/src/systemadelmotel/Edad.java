package systemadelmotel;

import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class Edad {
    public static boolean esMayorDeEdad(LocalDate fechaNacimiento) {
        LocalDate hoy = LocalDate.now();
        Period edad = Period.between(fechaNacimiento, hoy);
        return edad.getYears() >= 18;
    }
}