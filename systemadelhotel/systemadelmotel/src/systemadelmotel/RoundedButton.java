/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package systemadelmotel;

/**
 *
 * @author jashy
 */


import java.awt.*;
import javax.swing.JButton;

public class RoundedButton extends JButton {
    private boolean hover = false;

    public RoundedButton(String label) {
        super(label);
        setOpaque(false);
        setFocusPainted(false);
        setContentAreaFilled(false);
        setForeground(Color.WHITE);
        setFont(new Font("SansSerif", Font.BOLD, 14));
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    public void setHover(boolean hover) {
        this.hover = hover;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Color colorNormal = new Color(33, 150, 243);
        Color colorHover = new Color(25, 118, 210);

        g2.setColor(hover ? colorHover : colorNormal);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);

        super.paintComponent(g);
        g2.dispose();
    }

    @Override
    protected void paintBorder(Graphics g) {
        // sin borde
    }
}
