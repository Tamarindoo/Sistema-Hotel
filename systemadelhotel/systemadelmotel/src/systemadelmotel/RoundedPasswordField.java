/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package systemadelmotel;

/**
 *
 * @author jashy
 */

import javax.swing.*;
import java.awt.*;

public class RoundedPasswordField extends JPasswordField {
    public RoundedPasswordField(int size) {
        super(size);
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        setFont(new Font("SansSerif", Font.PLAIN, 14));
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
        super.paintComponent(g);
    }

    @Override
    protected void paintBorder(Graphics g) {
        g.setColor(new Color(180, 180, 180));
        g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 25, 25);
    }
}
