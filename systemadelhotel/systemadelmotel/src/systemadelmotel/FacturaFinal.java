package systemadelmotel;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;


import javax.swing.*;
import java.sql.*;

public class FacturaFinal extends JFrame {

    private String idHabitacion;

    public FacturaFinal(String idHab) {
        this.idHabitacion = idHab;
        setTitle("Factura Final");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTextArea area = new JTextArea();
        area.setEditable(false);

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "Romero10251530$");
            String sql = "SELECT Nombre, Identificacion, Servicios_extras, Fecha_ingreso, Fecha_lastday, clientetargeta, Precio_estadia, Total_serviciosx, productoconsuimido, Total_productosagregados FROM clientes WHERE idHabitacion = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, idHabitacion);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String nombre = rs.getString("Nombre");
                String cedula = rs.getString("Identificacion");
                String servicios = rs.getString("Servicios_extras");
                String fechaIn = rs.getString("Fecha_ingreso");
                String fechaOut = rs.getString("Fecha_lastday");
                String tarjeta = rs.getString("clientetargeta");
                String productos = rs.getString("productoconsuimido");

                // Validación segura para evitar null
                String precioEstadiaStr = rs.getString("Precio_estadia");
                String totalServiciosStr = rs.getString("Total_serviciosx");
                String totalProductosStr = rs.getString("Total_productosagregados");

                if (precioEstadiaStr == null || precioEstadiaStr.trim().isEmpty()) precioEstadiaStr = "0";
                if (totalServiciosStr == null || totalServiciosStr.trim().isEmpty()) totalServiciosStr = "0";
                if (totalProductosStr == null || totalProductosStr.trim().isEmpty()) totalProductosStr = "0";

                double precioEstadia = Double.parseDouble(precioEstadiaStr.trim());
                double totalServicios = Double.parseDouble(totalServiciosStr.trim());
                double totalProductos = Double.parseDouble(totalProductosStr.trim());

                double total = precioEstadia + totalServicios + totalProductos;

                String resumen = "------- FACTURA FINAL -------\n"
                        + "Cliente: " + nombre + "\n"
                        + "ID: " + cedula + "\n"
                        + "Check-in: " + fechaIn + "\n"
                        + "Check-out: " + fechaOut + "\n"
                        + "Servicios: " + servicios + " ($" + totalServicios + ")\n"
                        + "Productos: " + productos + " ($" + totalProductos + ")\n"
                        + "Estadía: $" + precioEstadia + "\n"
                        + "-----------------------------\n"
                        + "TOTAL A PAGAR: $" + String.format("%.2f", total);

                area.setText(resumen);

                // Eliminar cliente
                PreparedStatement borrarCliente = con.prepareStatement("DELETE FROM clientes WHERE idHabitacion = ?");
                borrarCliente.setString(1, idHabitacion);
                borrarCliente.executeUpdate();

                // Marcar habitación como disponible
                PreparedStatement liberar = con.prepareStatement("UPDATE habitacion SET Disponibilidad='Disponible' WHERE idHabitacion = ?");
                liberar.setString(1, idHabitacion);
                liberar.executeUpdate(); // ← Asegura liberar la habitación
            }

            con.close();
        } catch (Exception e) {
            area.setText("Error al cargar datos: " + e.getMessage());
        }

        add(new JScrollPane(area));
        setVisible(true);
    }
}