package systemadelmotel;

import java.util.Date;

public class Edad {

    public static boolean esMayorDeEdad(Date fechaNacimiento) {
        if (fechaNacimiento == null) {
            return false;
        }

        long tiempoDiferencia = new Date().getTime() - fechaNacimiento.getTime();
        long años = tiempoDiferencia / (1000L * 60 * 60 * 24 * 365);

        return años >= 18;
    }
}